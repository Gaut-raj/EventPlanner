
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EventPlanner planner = new EventPlanner();

        // Adding guests to the guest list
        System.out.println("Enter guest names (type 'done' when finished):");
        String guestName;
        while (!(guestName = scanner.nextLine()).equalsIgnoreCase("done")) {
            planner.addToGuestList(guestName); //Adds each guest to the guest list 
        }

        // Adding meals to the meal list
        System.out.println("Enter meal names and costs (type 'done' when finished):");
        String mealInput;
        while (!(mealInput = scanner.nextLine()).equalsIgnoreCase("done")) {
            planner.addToMealList(mealInput); //Adds each meal to the meal list 
        }

        // Adding expenses to the expense tracker
        System.out.println("Enter expenses and amounts (type 'done' when finished):");
        String expenseName;
        double expenseAmount;
        while (!(expenseName = scanner.next()).equalsIgnoreCase("done")) {
            expenseAmount = scanner.nextDouble();
            planner.addToExpenseTracker(expenseName, expenseAmount); //Adds each expense to the expense tracker
        }

        // Printing guest list
        planner.printGuestList();

        // Printing meal list
        planner.printMealList();

        // Printing expense tracker
        planner.printExpenseTracker();
        //Calculating and printing total costs 
        double totalMealCost = planner.getMealList().values().stream().mapToDouble(Double::doubleValue).sum();
        double totalExpenseCost = planner.getExpenseTracker().values().stream().mapToDouble(Double::doubleValue).sum();
        System.out.println("Total Meal Cost: $" + totalMealCost);
        System.out.println("Total Expense Cost: $" + totalExpenseCost); //Prints out total costs of the meal costs and other expenses 

        scanner.close(); //Closes scanner 
    }
}