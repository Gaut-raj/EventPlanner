/*
 * Author: Gautham Govindaraj 
 * Description: This class represents an EventPlanner which manages guest lists, meal lists, and expense tracking for an event.
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class EventPlanner {
//Declaring private variables 
    private List<String> guestList;
    private Map<String, Double> mealList;
    private Map<String, Double> expenseTracker;
    

    //Getter methods for lists 
     public Map<String, Double> getMealList() {
        return mealList;
    }

    public Map<String, Double> getExpenseTracker() {
        return expenseTracker;
    }
    //Constructor 
    public EventPlanner() {
        guestList = new ArrayList<>();
        mealList = new HashMap<>();
        expenseTracker = new HashMap<>();
    }
    //Method to add guests to the guest list 
    public void addToGuestList(String guest) {
        guestList.add(guest);
    }
    //Method to add meals to the meal list 
    public void addToMealList(String input) {
       
        String[] parts = input.split(",");
        if (parts.length == 2) {
            String mealName = parts[0].trim();
            double cost;
            try {
                cost = Double.parseDouble(parts[1].trim());
                mealList.put(mealName, cost);
            } catch (NumberFormatException e) {
                System.out.println("Invalid cost format for meal: " + input);
            }
        } else {
            System.out.println("Invalid input format for meal: " + input);
        }
    }
    //Method to add expenses to the expense tracker 
    public void addToExpenseTracker(String expense, double amount) {
        if (expenseTracker.containsKey(expense)) {
            double currentAmount = expenseTracker.get(expense);
            expenseTracker.put(expense, currentAmount + amount); 
        } else {
            expenseTracker.put(expense, amount);
        }
    }
    //Method to print the Guest list 
    public void printGuestList() {
        System.out.println("Guest List:");  
        for (String guest : guestList) {
            System.out.println(guest);
        }
    }
    //Method to print the meal list 
    public void printMealList() {
        System.out.println("Meal List:");
        for (Map.Entry<String, Double> entry : mealList.entrySet()) {
            System.out.println(entry.getKey() + " - Cost: $" + entry.getValue()); //Prints the list of meals 
        }
    }
    //Method to print the expense tracker 
    public void printExpenseTracker() {
        System.out.println("Expense Tracker:");
        for (Map.Entry<String, Double> entry : expenseTracker.entrySet()) {
            System.out.println(entry.getKey() + " - Amount: $" + entry.getValue()); //Keeps track of other expenses 
        }
    }
}
